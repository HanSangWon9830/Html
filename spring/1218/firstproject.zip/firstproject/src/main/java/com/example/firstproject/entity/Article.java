package com.example.firstproject.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.*;

@Entity //DB가 해당 객체를 인식가능하게 함
@Getter
@Setter
@ToString
@AllArgsConstructor //모든 생성자
@NoArgsConstructor //기본 생성자

public class Article {
    @Id //Entity에 대표값 - 식별
    @GeneratedValue //1,2,3 자동으로 번호 추가하는 어노테이션
    private Long id;

    @Column
    private  String title;

    @Column
    private String content;

//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//
//    public void setContent(String content) {
//        this.content = content;
//    }
//
//    public Long getId() {
//        return id;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public String getContent() {
//        return content;
//    }
//
//    public Article(Long id, String title, String content) {
//        this.id = id;
//        this.title = title;
//        this.content = content;
//    }
//
//    public Article() {
//
//    }
//
//    @Override
//    public String toString() {
//        return "Article{" +
//                "id=" + id +
//                ", title='" + title + '\'' +
//                ", content='" + content + '\'' +
//                '}';
//    }
}
