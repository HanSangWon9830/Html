package com.example.firstproject.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "article_id")
    private  Article article;
    //데이터베이스에서 생성될 외래키 이름 article_id
    //article_id는 comment 테이블에서 Article 테이블 참조하는 컬럼
    //다대일 관계

    @Column
    private String nickname;

    @Column
    private  String body;
}
