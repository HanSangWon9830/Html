package study.project_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
