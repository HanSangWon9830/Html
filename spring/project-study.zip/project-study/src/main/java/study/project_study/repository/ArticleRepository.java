package study.project_study.repository;

import org.springframework.data.repository.CrudRepository;
import study.project_study.entity.Article;

public interface ArticleRepository extends CrudRepository<Article, Long> {



}
