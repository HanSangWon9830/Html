package study.project_study.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import study.project_study.dto.ArticleForm;
import study.project_study.entity.Article;
import study.project_study.repository.ArticleRepository;

@Controller
public class ArticleConteoller{
    //articles/new 로 매핑하여 -> articles/new로 응답하게 해보시오

    @Autowired
    private ArticleRepository articleRepository;
    //외부에서 주입(객체를 하나만 만들기 위해서) - DI


    @GetMapping("articles/new")
    //localhost/articles/new
    public String newArticleForm(){
        return "articles/new";
    }
    @PostMapping("/articles/create")
    public  String createArticle(ArticleForm form){
        System.out.println(form.toString());

        //1.Dto를 Entity로 변환 ()
        //dto 타입으로 바로 저장이 어려우므로 article 타입으로 변환(이동);
        Article article = form.toEntity();
        System.out.println(article.toString());

        Article saved = articleRepository.save(article);
        System.out.println(saved.toString());

        return "";
    }

    @GetMapping("/articles/{id}")
        public String show(@PathVariable Long id, Model model){
        System.out.println("id = " +id);
        //1.id로 데이터를 가져옴
        Article articleEntity = articleRepository.findById(id).orElse(null);
        //2.가져온 데이터를 모델에 등록;
        model.addAttribute("article",articleEntity);

        //3. 보여줄 페이지 설정
        return  "articles/show";



    }

}
