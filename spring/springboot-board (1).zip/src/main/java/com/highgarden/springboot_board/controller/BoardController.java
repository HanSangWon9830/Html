package com.highgarden.springboot_board.controller;

import com.highgarden.springboot_board.dto.BoardDTO;
import com.highgarden.springboot_board.dto.BoardFileDTO;
import com.highgarden.springboot_board.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.io.IOException;
import java.util.List;

@Controller
@RequiredArgsConstructor//생성자방식으로 서비스 주입
public class BoardController {

    private final BoardService boardService;

    @GetMapping("/save")
    public String save(){
        return "save";
    }//Get 요청으로 들어오는 /save 글작성화면

    
    @PostMapping("/save")
    public String save(BoardDTO boardDTO) throws IOException {
        boardService.save(boardDTO);
        return "redirect:/list"; //새로고침
    }//Post 요청으로 들어오는 /save dB에 저장하는 기능
 //IOException 이 발생할 수 있으므로 예외를 thorws 로 던진다.
    @GetMapping("/list")
    public String findAll(Model model){
       List<BoardDTO> boardDTOList = boardService.findAll();
       model.addAttribute("boardList",boardDTOList);
       return "list";

    }

    @GetMapping("/{id}")
    public String findById(@PathVariable("id") Long id, Model model){
        //조회수 처리
        boardService.updateHits(id);
        //상세내용 가져오기
        BoardDTO boardDTO = boardService.findById(id);
        model.addAttribute("board", boardDTO);
        //파일첨부 추가된 부분
        if(boardDTO.getFileAttached() == 1){//첨부파일이 있으면
            List<BoardFileDTO> boardFileDTOList = boardService.findFile(id);
            model.addAttribute("boardFileDTOList", boardFileDTOList);
        }

        return "detail";
    }
//수정버튼 클릭싀 수정화면으로 넘어가도록 하는 메서드(Get)
@GetMapping("/update/{id}")
public String update(@PathVariable("id") Long id, Model model){
       BoardDTO boardDTO = boardService.findById(id);
       model.addAttribute("board",boardDTO);
       return "update";
}

//DB에 실질적으로 수정내용을 요청하는 메서드(post)
@PostMapping("/update/{id}")
    public String update1(BoardDTO boardDTO, Model model){
        //upddate 요청
     boardService.update(boardDTO);
     //findById로 수정된 내용을 다시조회
    BoardDTO dto= boardService.findById(boardDTO.getId());
    model.addAttribute("board",dto);
    return  "detail";  //업데이트후 조회하여 상세조회화면
}

@GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Long id){
    boardService.delete(id);
    return "redirect:/list";
}






}
